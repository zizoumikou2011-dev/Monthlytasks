
package com.example.monthlytasks;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(247,247,251), TEXT=Color.rgb(32,33,42), MUTED=Color.rgb(105,108,120);
    final int ACCENT=Color.rgb(91,95,239), GREEN=Color.rgb(30,150,92), GREEN_BG=Color.rgb(224,247,235);
    SharedPreferences prefs;
    LinearLayout root, grid;
    TextView percentText, countText, monthTitle;
    Calendar view=Calendar.getInstance();

    String[] months={"يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"};
    String[] week={"الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"};

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(TEXT); b.setTextSize(13); b.setAllCaps(false);
        b.setBackground(bg(Color.WHITE,12)); b.setPadding(dp(8),0,dp(8),0); return b;
    }

    public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("tasks_pro",MODE_PRIVATE);
        build();
        render();
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(12),dp(16),dp(12)); root.setBackgroundColor(BG);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView title=text("مهامي اليومية",24,TEXT); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView sub=text("تابع عاداتك وأنجز مهامك كل يوم",13,MUTED);
        titles.addView(title,new LinearLayout.LayoutParams(0,dp(36),1)); titles.addView(sub,new LinearLayout.LayoutParams(0,dp(28),1));
        top.addView(titles,new LinearLayout.LayoutParams(0,dp(68),1));
        Button reset=button("تصفير الشهر"); reset.setOnClickListener(v->clearMonth());
        top.addView(reset,new LinearLayout.LayoutParams(dp(105),dp(48)));
        root.addView(top);

        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(12),dp(16),dp(12)); card.setBackground(bg(Color.WHITE,18));
        LinearLayout cardTop=new LinearLayout(this);
        monthTitle=text("",18,TEXT); monthTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        cardTop.addView(monthTitle,new LinearLayout.LayoutParams(0,dp(38),1));
        Button prev=button("‹"); Button next=button("›");
        cardTop.addView(prev,new LinearLayout.LayoutParams(dp(44),dp(42))); cardTop.addView(next,new LinearLayout.LayoutParams(dp(44),dp(42)));
        card.addView(cardTop);
        percentText=text("0%",30,ACCENT); percentText.setTypeface(Typeface.DEFAULT,Typeface.BOLD); percentText.setGravity(Gravity.CENTER);
        card.addView(percentText,new LinearLayout.LayoutParams(-1,dp(42)));
        countText=text("0 من 0 إنجاز",13,MUTED); countText.setGravity(Gravity.CENTER);
        card.addView(countText,new LinearLayout.LayoutParams(-1,dp(24)));
        root.addView(card,new LinearLayout.LayoutParams(-1,dp(150)));

        prev.setOnClickListener(v->{view.add(Calendar.MONTH,-1);render();});
        next.setOnClickListener(v->{view.add(Calendar.MONTH,1);render();});

        Space sp=new Space(this); root.addView(sp,new LinearLayout.LayoutParams(1,dp(10)));

        LinearLayout add=new LinearLayout(this);
        EditText input=new EditText(this); input.setHint("مثال: قراءة 20 دقيقة"); input.setTextSize(15); input.setSingleLine(true);
        Button addBtn=button("+ إضافة"); addBtn.setTextColor(Color.WHITE); addBtn.setBackground(bg(ACCENT,12));
        add.addView(input,new LinearLayout.LayoutParams(0,dp(52),1)); add.addView(addBtn,new LinearLayout.LayoutParams(dp(92),dp(52)));
        root.addView(add);

        grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); scroll.addView(grid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        addBtn.setOnClickListener(v->{String n=input.getText().toString().trim(); if(n.isEmpty())return;
            String old=prefs.getString("names",""); prefs.edit().putString("names",old.isEmpty()?n:old+"|"+n).apply(); input.setText(""); render();});
        setContentView(root);
    }

    String[] taskNames(){
        String names=prefs.getString("names","");
        if(names.isEmpty()) return new String[]{"الدراسة","الرياضة","القراءة","شرب الماء"};
        return names.split("\\|");
    }

    String key(String name,int day){return view.get(Calendar.YEAR)+"_"+view.get(Calendar.MONTH)+"_"+day+"_"+name;}

    void render(){
        monthTitle.setText(months[view.get(Calendar.MONTH)]+" "+view.get(Calendar.YEAR));
        grid.removeAllViews();
        String[] names=taskNames();
        int days=new GregorianCalendar(view.get(Calendar.YEAR),view.get(Calendar.MONTH),1).getActualMaximum(Calendar.DAY_OF_MONTH);
        int total=names.length*days, done=0;

        for(String name:names){
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14),dp(8),dp(14),dp(10)); card.setBackground(bg(Color.WHITE,16));
            LinearLayout row=new LinearLayout(this);
            TextView nt=text(name,16,TEXT); nt.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            row.addView(nt,new LinearLayout.LayoutParams(0,dp(42),1));
            int td=0; for(int d=1;d<=days;d++)if(prefs.getBoolean(key(name,d),false))td++;
            TextView small=text(td+" / "+days,12,MUTED); small.setGravity(Gravity.CENTER);
            row.addView(small,new LinearLayout.LayoutParams(dp(65),dp(42)));
            Button del=button("×"); del.setTextColor(Color.RED); del.setOnClickListener(v->deleteTask(name));
            row.addView(del,new LinearLayout.LayoutParams(dp(42),dp(42)));
            card.addView(row);

            HorizontalScrollView hs=new HorizontalScrollView(this);
            LinearLayout cells=new LinearLayout(this);
            Calendar c=new GregorianCalendar(view.get(Calendar.YEAR),view.get(Calendar.MONTH),1);
            for(int d=1;d<=days;d++){
                boolean checked=prefs.getBoolean(key(name,d),false); if(checked)done++;
                final int day=d; final String k=key(name,d);
                Button b=button(checked?"×":String.valueOf(d));
                b.setTextSize(12); b.setGravity(Gravity.CENTER);
                b.setTextColor(checked?GREEN:MUTED); b.setBackground(bg(checked?GREEN_BG:Color.rgb(244,244,248),10));
                b.setOnClickListener(v->{boolean nv=!prefs.getBoolean(k,false);prefs.edit().putBoolean(k,nv).apply();render();});
                cells.addView(b,new LinearLayout.LayoutParams(dp(48),dp(42)));
                if(d<days){Space s=new Space(this);cells.addView(s,new LinearLayout.LayoutParams(dp(5),1));}
            }
            hs.addView(cells); card.addView(hs);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(115)); cp.setMargins(0,0,0,dp(10)); grid.addView(card,cp);
        }
        int pct=total==0?0:(done*100/total);
        percentText.setText(pct+"%");
        countText.setText(done+" من "+total+" إنجاز");
    }

    void deleteTask(String name){
        new AlertDialog.Builder(this).setTitle("حذف المهمة؟").setMessage("سيتم حذف \""+name+"\" وعلاماتها.")
        .setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{
            StringBuilder sb=new StringBuilder(); for(String n:taskNames())if(!n.equals(name)){if(sb.length()>0)sb.append("|");sb.append(n);}
            prefs.edit().putString("names",sb.toString()).apply(); render();
        }).show();
    }

    void clearMonth(){
        new AlertDialog.Builder(this).setTitle("تصفير الشهر؟").setMessage("سيتم إزالة كل علامات الإنجاز لهذا الشهر فقط.")
        .setNegativeButton("إلغاء",null).setPositiveButton("تصفير",(d,w)->{
            int days=new GregorianCalendar(view.get(Calendar.YEAR),view.get(Calendar.MONTH),1).getActualMaximum(Calendar.DAY_OF_MONTH);
            SharedPreferences.Editor e=prefs.edit();
            for(String n:taskNames())for(int day=1;day<=days;day++)e.remove(key(n,day));
            e.apply(); render();
        }).show();
    }
}
